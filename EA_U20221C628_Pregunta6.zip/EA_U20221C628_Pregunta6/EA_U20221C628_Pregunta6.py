'''
Existe una red de carreteras a partir de la tabla de los caminos (distancias) más cortos entre cada par de pueblos en el mapa. Todos
 los caminos son de doble sentido. La ubicación de los pueblos en el mapa tienen las siguientes propiedades interesantes:

Si la longitud del camino más corto desde el pueblo A al pueblo B es igual a la suma de las longitudes de los caminos más cortos 
desde A a C y C a B, entonces el pueblo C se encuentra en ( cierto) camino más corto de A a B. 
Decimos que los pueblos A y B son pueblos vecinos si no hay ningún pueblo C tal que la longitud del camino más corto de A a B sea 
igual a la suma de las longitudes de los caminos más cortos de A a C y de C a B
'''

#El algoritmo de base que tome en cuenta para resolver esto fue de Fuerza Bruta
# puesto que, se tiene que recorrer cada par de nodos i y j y para cada par de nodos i y j se tiene que recorrer cada nodo k
# para verificar si la distancia de i a j es igual a la suma de las distancias de i a k y de k a j. Si no se cumple esta condición
# entonces se añade el par de nodos i y j a la lista de vecinos.

def encontrarVecinos(distancias, cantidadPueblos):
    vecinos = [] #Array de vecinos que retornara la respuesta.
    # Reviso cada pueblo i y j
    for i in range(cantidadPueblos):
        for j in range(i + 1, cantidadPueblos):
            esVecino = True
            for k in range(cantidadPueblos):
                if k != i and k != j and distancias[i][j] == distancias[i][k] + distancias[k][j]:
                    esVecino = False
                    break
            if esVecino:
                vecinos.append((i + 1, j + 1))
    return vecinos



#Codigo que abre el archivo .txt en modo lectura con 'r'  
with open('tabla_caminos.txt', 'r') as file:
    tests = int(file.readline().strip()) # Leer el número de casos de prueba
    resultados = [] # Lista para almacenar los resultados de cada caso de prueba
    
    for _ in range(tests):
        n = int(file.readline().strip()) # Leer el número de pueblos
        distancias = []
        
        # Con este for leo las distancias entre los pueblos
        for __ in range(n):
            row = list(map(int, file.readline().strip().split()))
            distancias.append(row)
        
        # Procesar cada caso usando la función de encontrar vecinos.
        vecinos = encontrarVecinos(distancias, n)
        resultados.append(vecinos)
    
    # Imprimir resultados
    for vecinos in resultados:
        for a, b in sorted(vecinos):
            print(a, b)



